const items =  [
  {
    id:1,
    "name": "Laptop",
    "quantity": 10,
    "price": 75000
  },
  {
    id:2,
    "name": "Mouse",
    "quantity": 50,
    "price": 500
  },
  {
    id:3,
    "name": "Keyboard",
    "quantity": 30,
    "price": 1200
  }
]
module.exports = items;