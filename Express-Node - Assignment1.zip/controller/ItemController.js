const items = require("../model/ItemModel");

//Get Method
const getItems = (req,res) => {
    res.status(200).json(items);
}
//Post Method (Create)
const createItems = ( req,res) => {
    // const id = parseInt(req.params.id);
    const {name,quantity,price} = req.body;
    if(!name || !quantity || !price) {
        res.status(404).json({message:"Product failed to created"})
    } 
    const newItems = {
        id:  items.length ? items[items.length -1].id + 1 : 1,
        name,
        quantity,
        price
    }
    items.push(newItems);
    res.status(401).json({message:"Product Created Successfully"})
}

//Put Method(Update)
const editItems = (req,res) => {
const id = parseInt(req.params.id);
const {name,quantity,price} = req.body;
const item = items.find(data => data.id === id);
//Update a data 
if(item){
    item.name = name ?? item.name;
    item.quantity = quantity ?? item.quantity;
    item.price = price ?? item.price;
    res.status(200).json({message:"Item Updated Successfully"});
}
else{
    res.status(404).json({message:"Item is failed to Updated"});
}

}
//Delete Method 
const deleteItems = (req,res) => {
const id = parseInt(req.params.id);
const {name,quantity,price} = req.body;
const index = items.findIndex(data => data.id == id);
if(index != -1){
    const deleteItem = items.splice(index,1); 
    res.status(200).json({message:"Item deleted successfully"})

}
else{
    res.status(404).json({message:"Item is failed to delete"})
}
}
module.exports = { getItems,createItems,editItems,deleteItems}